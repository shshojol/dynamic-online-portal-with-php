const debug = (): void => {
  // tslint:disable-next-line:no-debugger
  debugger;
};

const pass = (): void => {};

export {
  debug,
  pass
};

-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 31, 2021 at 09:35 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.1.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbus_002`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(2000) NOT NULL,
  `categoryid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`, `description`, `categoryid`) VALUES
(1, 'national', 'this is nation news', 0),
(2, 'internation', 'this is internation news', 0),
(3, 'politics', 'this is nation politics news', 1),
(4, 'sports', 'this is sports news ', 0),
(5, 'Football', 'this is football', 4),
(6, 'spanis leage', '', 5),
(7, 'la liga', '', 6),
(9, 'Entertainment', '', 1),
(10, 'Media', '', 1),
(11, 'Desi food', '', 1),
(12, 'hollywood', '', 2),
(13, 'bollywood', '', 2),
(14, 'cricket', '', 4),
(15, 'Basketball', '', 4),
(16, 'English premire leage', '', 5),
(17, 'tenis', '', 4),
(18, 'Dallywood', '', 9),
(19, 'jokes', '', 9),
(20, 'natok', '', 10);

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE `city` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`id`, `name`) VALUES
(9, '<b>khulna</b>'),
(2, 'chottogram'),
(4, 'cummila'),
(1, 'dhaka'),
(6, 'pabna'),
(8, 'ponchogor\'s'),
(7, 'rajshahi'),
(5, 'rangpur'),
(3, 'sylet');

-- --------------------------------------------------------

--
-- Table structure for table `pagecomment`
--

CREATE TABLE `pagecomment` (
  `id` int(11) NOT NULL,
  `pageid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `datetime` datetime NOT NULL DEFAULT current_timestamp(),
  `comment` varchar(2000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pagecomment`
--

INSERT INTO `pagecomment` (`id`, `pageid`, `userid`, `datetime`, `comment`) VALUES
(1, 5, 1, '2021-03-11 14:47:55', 'good news'),
(2, 1, 1, '2021-03-12 17:28:31', 'faltu news'),
(3, 1, 1, '2021-03-12 17:28:40', 'faltu'),
(4, 5, 1, '2021-03-12 17:33:59', 'bal khele'),
(5, 7, 1, '2021-03-12 17:34:24', 'fashi chai halar puter'),
(6, 1, 1, '2021-03-14 23:01:22', 'misa ktha'),
(7, 9, 1, '2021-03-20 16:02:43', 'realy they are gd'),
(8, 9, 1, '2021-03-20 16:11:37', 'gd news\r\n'),
(9, 9, 1, '2021-03-20 16:11:45', 'gd news\r\n'),
(10, 9, 1, '2021-03-20 16:11:53', 'gd news\r\n'),
(11, 1, 1, '2021-03-20 16:13:23', 'gd'),
(12, 1, 1, '2021-03-20 16:13:59', 'no'),
(13, 1, 1, '2021-03-20 16:14:08', 'no'),
(14, 6, 1, '2021-03-21 14:07:50', 'gd news'),
(15, 6, 1, '2021-03-21 14:08:24', 'fake news');

-- --------------------------------------------------------

--
-- Table structure for table `pagefile`
--

CREATE TABLE `pagefile` (
  `id` int(11) NOT NULL,
  `pageid` int(11) NOT NULL,
  `title` varchar(2000) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `file` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pagefile`
--

INSERT INTO `pagefile` (`id`, `pageid`, `title`, `date`, `file`) VALUES
(1, 1, 'cv', '2021-03-19 12:43:02', 'Carrykoro- INVOICE - Copy.docx');

-- --------------------------------------------------------

--
-- Table structure for table `pageimage`
--

CREATE TABLE `pageimage` (
  `id` int(11) NOT NULL,
  `pageid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pageimage`
--

INSERT INTO `pageimage` (`id`, `pageid`, `title`, `datetime`, `image`) VALUES
(5, 1, 'Tv', '2021-03-18 20:50:03', '4-original-image.jpg'),
(6, 1, 'image 2', '2021-03-19 10:02:15', '9.jpg'),
(7, 3, 'image 2', '2021-03-19 10:02:34', '10.jpg'),
(8, 3, 'Bangladesh send India to bat', '2021-03-19 10:02:48', '14.jpg'),
(9, 6, '\'Friends\' reunion finally happening', '2021-03-19 10:03:06', '14.jpg'),
(10, 9, 'side picture', '2021-03-19 10:03:21', '19.png'),
(11, 11, 'bating image', '2021-03-19 10:23:50', '1566985969IMG_2758.jpg'),
(12, 11, 'Bangladesh send India to bat', '2021-03-19 10:25:18', '1541651624IMG_9759.jpg'),
(13, 10, 'dead body', '2021-03-19 10:25:48', '1451279515AUGUST 2012.jpg'),
(14, 10, 'dead', '2021-03-19 10:26:05', '19.png'),
(15, 8, 'jkj', '2021-03-19 10:26:27', '14.jpg'),
(16, 8, 'side picture', '2021-03-19 10:26:44', '26.jpg'),
(17, 7, 'Bangladesh send India to bat', '2021-03-19 10:26:59', '13.jpg'),
(18, 1, 'Tv', '2021-03-19 10:27:13', '1451282251Lab -2.jpg'),
(19, 4, 'Nayeem bags two in succession after Mushy\'s double ton', '2021-03-19 10:27:32', '1451280149DSC_0138.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `pagelike`
--

CREATE TABLE `pagelike` (
  `pageid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `date` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pagelike`
--

INSERT INTO `pagelike` (`pageid`, `userid`, `date`) VALUES
(1, 1, '2021-03-22 01:36:13'),
(1, 3, '2021-03-20 16:25:10'),
(1, 4, '2021-03-20 16:25:10'),
(3, 1, '2021-03-20 18:16:40'),
(4, 1, '2021-03-20 18:16:44'),
(5, 1, '2021-03-21 13:37:47'),
(6, 1, '2021-03-21 13:37:55'),
(9, 1, '2021-03-20 18:16:52'),
(10, 1, '2021-03-20 18:16:55');

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` int(11) NOT NULL,
  `title` varchar(2000) NOT NULL,
  `tag` varchar(2000) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `hitcount` int(11) DEFAULT NULL,
  `categoryid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `title`, `tag`, `createdate`, `userid`, `hitcount`, `categoryid`) VALUES
(1, '‘ক্ষিপ্ত হয়ে অনেক কথা বলেছেন, যেটা মিথ্যাচার’', 'যেটা মিথ্যাচার', '2021-03-09 00:00:00', 1, 0, 3),
(3, 'আবার রক্ত ঝরল বসুরহাটে, সংঘর্ষ-গুলিতে নিহত ১', 'আবার রক্ত ', '2021-03-09 00:00:00', 1, 0, 1),
(4, 'তাজরিয়ান হত্যা মামলায় ‘পূর্বপরিচিত’ আমীর রিমান্ডে', 'তাজরিয়ান হত্যা', '2021-03-09 00:00:00', 1, 0, 1),
(5, 'মেসিদের মুখোমুখি হওয়া হচ্ছে না নেইমারের', 'মেসিদের ', '2021-03-09 00:00:00', 1, 0, 5),
(6, 'জামাল না খেলতে পারলে সমস্যা দেখছেন না কোচ', 'জামাল ', '2021-03-09 00:00:00', 1, 0, 5),
(7, 'সাকিবকে হুমকিদাতার জামিন কেন নয়', 'সাকিবকে', '2021-03-09 00:00:00', 1, 0, 4),
(8, 'আইপিএল খেলতে স্ত্রী–সন্তানদের ছেড়ে থাকা যায় কিন্তু...', 'আইপিএল খেলতে স্ত্রী–সন্তানদের ', '2021-03-09 00:00:00', 1, 0, 4),
(9, 'পশ্চিমবঙ্গে বিজেপির আসন কমছে, পাল্লা ভারী মমতার', 'পশ্চিমবঙ্গে ', '2021-03-09 00:00:00', 1, 0, 2),
(10, 'কলকাতায় রেল ভবনে আগুনে ৯ জনের মৃত্যু', 'কলকাতায় ', '2021-03-09 00:00:00', 1, 0, 2),
(11, 'Bangladesh send India to bat2', 'sports', '2021-03-14 08:00:00', 1, 0, 14),
(12, 'Nothing new, never dull', 'shakib', '2021-03-22 09:00:00', 1, 0, 4),
(13, 'Holder stars as Windies take control against Sri Lanka', 'west indies', '2021-03-22 09:00:00', 1, 0, 4),
(14, 'Booming orders bolster e-commerce logistics', 'booming', '2021-03-22 09:00:00', 1, 0, 1),
(15, 'Arsenic Contamination in Water: No proper study done in years', 'Arsenic', '2021-03-22 09:00:00', 1, 0, 1),
(16, 'Fire breaks out at building in Motijheel', 'Fire breaks', '2021-03-22 09:00:00', 1, 0, 1),
(17, 'World Water Day: Cry for water in the south', 'World Water Day: ', '2021-03-22 09:00:00', 1, 0, 1),
(18, 'Balukhali Rohingya camp fire: 2 children killed, several people suffer burn injuries', 'Balukhali Rohingya camp fire', '2021-03-22 20:00:00', 1, 0, 1),
(19, '50 years of independence: Better use of resources can be a game changer', '50 years of independence', '2021-03-22 20:00:00', 1, 0, 1),
(20, 'Vaccine drive loses steam', 'Vaccine drive loses steam', '2021-03-22 20:00:00', 1, 0, 10);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `cityid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `name`, `email`, `contact`, `address`, `cityid`) VALUES
(1, 'jhon', 'jhon@gmail.com', '0157466544', 'new york usa', 1),
(2, 'raj rahman', 'raj@gmail.com', '01682623426', 'dhaka dhanmondi', 1),
(3, 'rohan', 'rohan@gmail.com', '01682623426', 'puran dhaka', 1),
(4, 'alomgir khan', 'kodom@yahoo.com', '01358', 'chandina', 2),
(5, 'sholel', 'fal@gmail.com', '456789', 'dhanmondi', 7),
(6, 'sahor', 'genty@gmail.com', '123', 'new market', 2),
(7, 'sanjida\"s khan', 'sfas@gmail', '123', 'kalshi dhaka', 7);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(2000) NOT NULL,
  `createdate` datetime NOT NULL DEFAULT current_timestamp(),
  `createip` varchar(200) NOT NULL,
  `type` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `contact`, `email`, `password`, `createdate`, `createip`, `type`) VALUES
(1, 'sh shojol', '01682623426', 'shojolsh@gmail.com', '*3A4637497C8D12511BD6C720153DE6B8A1191721', '2021-03-14 22:45:06', '127.0127.02', 'a'),
(3, 'Parvej', '1234', 'parvej@gmail.com', '12345', '2021-03-14 22:46:00', '120.02.258', 'u'),
(4, 'sagor', '01358', 'sagor@gmail.com', '*00A51F3F48415C7D4E8908980D443C29C69B60C9', '2021-03-16 12:53:32', '::1', 'u'),
(6, 'hasan', '013588', 'hasan@gmail.com', '*00A51F3F48415C7D4E8908980D443C29C69B60C9', '2021-03-16 13:19:45', '::1', 'u'),
(7, 'sohel', '01577426552', 'sohel@gmail.com', '*00A51F3F48415C7D4E8908980D443C29C69B60C9', '2021-03-17 14:00:08', '::1', 'u'),
(9, 'pias', '012584525685552', 'pias@gmail.com', '*00A51F3F48415C7D4E8908980D443C29C69B60C9', '2021-03-17 14:04:45', '::1', 'u'),
(11, 'tuhin', '45549855', 'tuhin@gmail.com', '*00A51F3F48415C7D4E8908980D443C29C69B60C9', '2021-03-17 16:35:16', '::1', 'u'),
(13, 'sohan', '646444646', 'sohan@gmail.com', '*00A51F3F48415C7D4E8908980D443C29C69B60C9', '2021-03-17 22:19:06', '::1', 'u'),
(16, 'sohan', '64644464654', 'sohan2@gmail.com', '*00A51F3F48415C7D4E8908980D443C29C69B60C9', '2021-03-17 22:19:38', '::1', 'u'),
(17, 'genty mia', '564946416', 'genty@gmail.com', '*00A51F3F48415C7D4E8908980D443C29C69B60C9', '2021-03-17 22:33:25', '::1', 'u'),
(18, 'orni', '67494641651', 'orni@gmail.com', '*00A51F3F48415C7D4E8908980D443C29C69B60C9', '2021-03-17 22:49:38', '::1', 'u'),
(19, 'jahid', '94616468', 'jahid@gmail.com', '*00A51F3F48415C7D4E8908980D443C29C69B60C9', '2021-03-17 23:16:57', '::1', 'u'),
(20, 'abc', '946642', 'abc@gmail.com', '*00A51F3F48415C7D4E8908980D443C29C69B60C9', '2021-03-17 23:18:29', '::1', 'u'),
(22, 'adda', '0135887678678', 'adda@gmail.com', '*00A51F3F48415C7D4E8908980D443C29C69B60C9', '2021-03-26 18:56:27', '::1', 'u');

-- --------------------------------------------------------

--
-- Table structure for table `usersactive`
--

CREATE TABLE `usersactive` (
  `userid` int(11) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `usersactive`
--

INSERT INTO `usersactive` (`userid`, `ip`, `date`) VALUES
(1, '125.02', '2021-03-17 11:00:24'),
(18, '::1', '2021-03-17 16:51:03'),
(22, '::1', '2021-03-26 12:56:42');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `city`
--
ALTER TABLE `city`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `pagecomment`
--
ALTER TABLE `pagecomment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pagefile`
--
ALTER TABLE `pagefile`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pageimage`
--
ALTER TABLE `pageimage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pagelike`
--
ALTER TABLE `pagelike`
  ADD PRIMARY KEY (`pageid`,`userid`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `title` (`title`) USING HASH;

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `contact` (`contact`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `usersactive`
--
ALTER TABLE `usersactive`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `city`
--
ALTER TABLE `city`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `pagecomment`
--
ALTER TABLE `pagecomment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `pagefile`
--
ALTER TABLE `pagefile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `pageimage`
--
ALTER TABLE `pageimage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<form action="" method="post">
    <label>Name</label><br>
    <input type='text' name='name' value='<?PHP echo $name;?>'><?PHP echo $ename;?><br>
    
    <label>contact</label><br>
    <input type='text' name='contact' value='<?PHP echo $contact;?>'><?PHP echo $econtact;?><br>
    
    <label>Email</label><br>
    <input type='text' name='email' value='<?PHP echo $email;?>'><?PHP echo $eemail;?><br>
    
    <label>Password</label><br>
    <input type='text' name='password' value='<?PHP echo $password;?>' ><?PHP echo $epassword;?><br>
    
    <label>Password Retype</label><br>
    <input type='text' name='passwordRetype' value='<?PHP echo $passwordRetype;?>' ><?PHP echo $epasswordRetype;?><br>

    <br><input type="submit" name='submit' value='submit'>
</form>
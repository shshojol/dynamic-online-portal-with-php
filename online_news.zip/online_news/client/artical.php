<?php
    $search = "";
    $esearch = "";
    if(isset($_POST['btnSearch']))
    {
        $search = $_POST['search'];
    }
?>
<form action="" method="post">
    <input type='text' name='search' value="<?php echo $search;?>">
    <input type='submit' name="btnSearch" value='Search'>
</form>
<?php
    $a = array();
    
    findSubCategory($_GET['ctg'], $a);

    if(isset($_GET['likeid']) && isset($_SESSION['type']))
    {
        global $cn;
        $sql = "insert into pagelike(pageid, userid) values(".$_GET['likeid'].", ".$_SESSION['id'].")";
        mysqli_query($cn, $sql);
    }

     $cn = mysqli_connect("localhost", "root", "", "dbus_002");
     $sql = "select p.id, p.title, p.tag, p.createdate, p.userid, p.hitcount, c.name as category,
     ( select count(id) from pagecomment where pageid = p.id) as comment
     from pages as p
     left join category as c on p.categoryid = c.id where p.categoryid in(".implode(",", $a).")";

    if($search != "")
    {
        $sql .= " and (p.title like '%".mss($search)."%' or p.tag like '%".mss($search)."%')";
    }

     $table = mysqli_query($cn, $sql);

     $totalitem = mysqli_num_rows($table);
    $page = 1;
    if(isset($_GET['page']))
    {
        $page = $_GET['page'];
    }
     
  

     $sql .= " limit ".(($page - 1) * 4).", 4";
     $table = mysqli_query($cn, $sql);
     
    
    $lastpage = $totalitem / 4;
    
    

     echo "".(($page - 1 ) * 4+1)." - ".(($page - 1) * 4+4)." / ".$totalitem."<br><hr>";
    if($page > 1) 
    {
        echo "<a href='?c=".$_GET['c']."&ctg=".$_GET['ctg']."'>First </a>";
        echo "<a href='?c=".$_GET['c']."&ctg=".$_GET['ctg']."&page= ".($page-1)."'>Previous </a>";
    }
   
    echo "<a href='?c=".$_GET['c']."&ctg=".$_GET['ctg']."&page= ".($page+1)."'>Next </a>";
    echo "<a href='?c=".$_GET['c']."&ctg=".$_GET['ctg']."&page= ".$lastpage."'>Last </a>";

    while($row = mysqli_fetch_assoc($table))
     {
        echo "<div class='artical'>";
         echo "<tr>";
             echo '<h1>'.$row['title'].'</h1>';
             echo '<h3>'.htmlentities($row['tag']).'</h3>';
             echo '<b>Create date: '.htmlentities($row['createdate']).' By: ';
             echo htmlentities($row['userid']).'<br>';
             echo 'Hit: '.htmlentities($row['hitcount']).' , in : ';
             echo htmlentities($row['category']).'</b></br>';
             

             $fileName = "artical/".str_replace(" ", "_", trim($row['title'])).".html";
             $file = fopen($fileName, 'r');
             $content = fread($file, filesize($fileName));

             findimage($row['id']);
             
             echo "<p>";
             print substr($content, 0, 1000);
             echo " ... .. . <a href='?c=articalDetails&pid=".$row['id']."'>Read More</a><br>";
             $likeuser = array();
    $likeusername = array();
             findlike($row['id'], $likeruser, $likeusername); 
             echo "</p>";
             echo "<div>";
             if(isset($_SESSION['type']))
             {
                 if(in_array($_SESSION['name'], $likeusername))
                 {
                     echo "<a href='#'>You and other like </a> : ";
                 }
                 else
                 {
                    echo "<b><a href='?c=".$_GET['c']."&ctg=".$_GET['ctg']."&likeid=".$row['id']."'>Like:</a> </b>";
                 }
               
             }
             else
             {
                 echo "like: ";
             }
             
             echo "<a href='#' title = '".implode("\n", $likeusername)."'>".count($likeusername)."</a>";
             echo "<b><a href='#'> comment: ".$row['comment']."</a></b>";
             echo "</div>";
             echo "</div>";
     }
     
function findSubCategory($cid, &$a)
{
    global $cn;
    $a[] = $cid;
    $sql = "select id from category where categoryid = ".$cid;
    $table = mysqli_query($cn, $sql);
    while($row = mysqli_fetch_assoc($table))
    {
        $a[] = $row['id'];
        findSubCategory($row['id'], $a);
    }
}
function findimage($pid)
{
    global $cn;
    $sql = 'select id, title, image from pageimage where pageid ='.$pid.' limit 0, 1';
    $table = mysqli_query($cn, $sql);
    while($row = mysqli_fetch_assoc($table))
    {
        echo '<img height="150px" src="upload/image/'.$row["id"].'_'.$row["image"].'" title="'.$row['title'].'"/>';
    }
}

function findlike($pid, &$likeuser, &$likeusername)
{
    global $cn;

    $sql = 'select pl.userid as userid, u.name as user, pl.date 
    from pagelike as pl
    left join users as u on pl.userid = u.id where pageid = '.$pid;
    $table = mysqli_query($cn, $sql);
    while($row = mysqli_fetch_assoc($table))
    {
        $likeuser[] = $row['userid'];  
        $likeusername[] = $row['user'];  
    }
    
}
     
?>
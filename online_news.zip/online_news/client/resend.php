<?PHP
    if(isset($_POST['resend']))
    {
        

    }
    else{
        
    }
?>
<form action="" method = "post">
    <label>Email</label>
    <input type="text" name='email' value="">
    <input type="submit" name='Resend' value="Resend Mail">
</form>
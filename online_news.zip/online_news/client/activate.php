<?php
    if(isset($_GET['id']))
    {
        $sql = "insert into usersactive(userid, ip) values(".mss($_GET['id']).", '".$_SERVER['REMOTE_ADDR']."')";
        if(mysqli_query($cn, $sql))
        {
            echo "your account has been activeted,you can login now.";
        }
        else
        {
            echo "you are already activeted";
        }
    }
?>
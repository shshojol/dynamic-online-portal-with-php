Logged out successfully<br>
<?php
    
?>
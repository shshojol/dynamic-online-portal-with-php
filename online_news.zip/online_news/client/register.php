<?PHP
$name = "";
$email = "";
$contact = "";
$password = "";
$passwordRetype = "";


$ename = "";
$eemail = "";
$econtact = "";
$epassword = "";
$epasswordRetype = "";

    
    if(isset($_POST['submit']))
    {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $contact = $_POST['contact'];
        $password = $_POST['password'];
        $passwordRetype = $_POST['passwordRetype'];

        

        $er=0;
        if($name == "")
        {
            $er++;
            $ename = "**";
        }
        if($email == "")
        {
            $er++;
            $eemail = "**";
        }
        if($contact == "")
        {
            $er++;
            $econtact = "**";
        }
        if($password == "")
        {
            $er++;
            $epassword = "**";   
        }
        if($passwordRetype == "")
        {
            $er++;
            $epasswordRetype = "**";   
        }
        elseif($password != $passwordRetype){
            $er++;
            $epasswordRetype = "Password not matched"; 
        }

        if($er == 0)
        {
            
            $sql = "INSERT INTO users (name, email, contact, password, createip, type) 
            VALUES ('".mss($name)."', '".mss($email)."', '".mss($contact)."', password('".mss($password)."'), '".$_SERVER['REMOTE_ADDR']."', 'u')";
           
            if(mysqli_query($cn,$sql))
            {
                echo "Registration Complete";
                $msg = "Dear ".$name."\n<br>";
                $msg .= "you have recently register out system plz click the link to active ur account.\n<br>";
                $msg .= '<a href="http://localhost/shojol/us_soft_002/?c=activate&id='.mysqli_insert_id($cn).'">Active account</a>\n<br>';
                $msg .= "If u have not register thn click the following link.\n";
                $msg .= '<a href="http://localhost/shojol/us_soft_002/?c=deactive&id='.mysqli_insert_id($cn).'">DeActive account</a>\n<br>';;
                //mail($email, 'account activation for bu.com', $msg);
                echo $msg;
           
            }
            else
            {
                echo mysqli_error($cn);
                include('client/registrationForm.php');
            }
            
        }else{
            include('client/registrationForm.php'); 
        }
    }else{
        include('client/registrationForm.php');
    }
?>


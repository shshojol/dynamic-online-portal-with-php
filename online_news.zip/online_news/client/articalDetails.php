
<?php

    if(isset($_GET['likeid']) && isset($_SESSION['type']))
    {
      global $cn;
      $sql = "insert into pagelike(userid, pageid) values(".$_SESSION['id'].", ".$_GET['likeid'].")";
      mysqli_query($cn, $sql);
    }


     $cn = mysqli_connect("localhost", "root", "", "dbus_002");
     $sql = "select p.id, p.title, p.tag, p.createdate, p.userid, p.hitcount, c.name as category,
     ( select count(id) from pagecomment where pageid = p.id) as comment
     from pages as p
     left join category as c on p.categoryid = c.id where p.id =".$_GET['pid'];
     $table = mysqli_query($cn, $sql);

     echo "Total ".mysqli_num_rows($table)." Artical found in this category <br><hr>";
     
    while($row = mysqli_fetch_assoc($table))
     {
        echo "<div class='artical'>";
         echo "<tr>";
             echo '<h1>'.$row['title'].'</h1>';
             echo '<h3>'.htmlentities($row['tag']).'</h3>';
             echo '<b>Create date: '.htmlentities($row['createdate']).' By: ';
             echo htmlentities($row['userid']).'<br>';
             echo 'Hit: '.htmlentities($row['hitcount']).' , in : ';
             echo htmlentities($row['category']).'</b></br>';
             

             $fileName = "artical/".str_replace(" ", "_", trim($row['title'])).".html";
             $file = fopen($fileName, 'r');
             $content = fread($file, filesize($fileName));

             findimage($row['id']);

             print '<p>'.$content.'</p>';
             echo " <br>";
             $likeusername = array();
              $likeuser = array();
             findlike($row['id'], $likeuser, $likeusername);
             if($_SESSION['type'])
             {
               if(in_array($_SESSION['name'], $likeusername))
               {
                echo "<a href='#'>You and other like </a> : ";
               }
               else
               {
                echo "<b><a href='?c=".$_GET['c']."&pid=".$_GET['pid']."&likeid=".$row['id']."'>Like:</a></b>";
               }
                
             }
             else
             {
                echo "like: ";
             }
             
             echo "<a href='#' title='".implode("\n", $likeusername)."'>".count($likeusername)."</a>";
             echo "<b><a href='#'>comment: ".$row['comment']."</a></b>";
             echo "</div>";
     }

    
  ?>
 <?PHP
  if(isset($_SESSION['type']))
  {
    echo " <form action='' method='post'>
    <label>Comment</label><br>
    <textarea name='comment'></textarea><br>
    <input type='submit' name='submit' value='submit'>
 </form>";
  }
  $commet = "";
  $ecomment = "";
  if(isset($_POST['submit']))
  {
    $comment = $_POST['comment'];
    $er = 0;
    if($comment == "")
    {
      $er++;
      $ecomment = "required";
    }
    if($er == 0)
    {
      global $cn;
      $sql2 = "insert into pagecomment (pageid, userid, comment)
      values(".$_GET['pid'].", 1, '".mysqli_real_escape_string($cn, $comment)."')";
     if(!mysqli_query($cn, $sql2))
     {
       echo mysqli_error($cn);
     }
    }
  }
 ?>
  <?php


  $cn = mysqli_connect("localhost", "root", "", "dbus_002");
  $sql = "select id, userid, datetime, comment from pagecomment where pageid = ".$_GET['pid'];
  $table = mysqli_query($cn, $sql);
  
  while($row = mysqli_fetch_assoc($table))
  {
    echo "<div class='comment'>";
      echo $row['userid']."<br>";
      echo $row['comment']."<br>";
      echo $row['datetime']."<br>";
      echo "</div>";
  }
  
  function findimage($pid)
  {
      global $cn;
      $sql = 'select id, title, image from pageimage where pageid ='.$pid;
      $table = mysqli_query($cn, $sql);
      while($row = mysqli_fetch_assoc($table))
      {
          echo '<img height="150px" src="upload/image/'.$row["id"].'_'.$row["image"].'" title="'.$row['title'].'"/>';
      }
  }

  function findlike($pid, &$likeuser, &$likeusername)
  {
      global $cn;
  
      $sql = 'select pl.userid as userid, u.name as user, pl.date 
      from pagelike as pl
      left join users as u on pl.userid = u.id where pageid = '.$pid;
      $table = mysqli_query($cn, $sql);
      while($row = mysqli_fetch_assoc($table))
      {
          $likeuser[] = $row['userid'];  
          $likeusername[] = $row['user'];  
      }
      
  }
?>

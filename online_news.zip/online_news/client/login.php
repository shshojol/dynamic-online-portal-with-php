

<form action="" method="post">
    <label>Email</label><br>
    <input type="text" name= "email" value="<?PHP echo $email;?>"><?PHP echo $eemail; ?><br>

    <label>Password</label><br>
    <input type="text" name= "password" value="<?PHP echo $password;?>"><?PHP echo $epassword; ?><br>
    <input type = 'checkbox' value='1' name='remember'>Remember me <br><br>
    <input type='submit' name='btnlogin' value='submit'>
    
</form>
<div>
    <a href='?c=forgot'>Forgot Password</a>
</div>
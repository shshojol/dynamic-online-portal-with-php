<?php
    if(isset($_GET['id']))
    {
        $sql = "DELETE FROM users WHERE id = ".$_GET['id'];
        if(mysqli_query($cn, $sql))
        {
            echo "Your account deactivated";
        }
        else
        {
            echo "you are already deactiveted";
        }
    }
?>
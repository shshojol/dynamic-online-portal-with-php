<ul id="css3menu1" class="topmenu">
    <li><a href="?c=home">Home</a></li>
        <?PHP
            $cn = mysqli_connect('localhost', 'root', '', 'dbus_002');
            $sql = "select id,name from category where categoryid=0";
            $table = mysqli_query($cn, $sql);              
            while($row = mysqli_fetch_assoc($table))
                {
                   echo  "<li><a href='?c=artical&ctg=".$row['id']."'>".$row['name'] ."</a>";
                   findchild($row['id']); 
                   echo "<li>" ; 
                }
                    function findchild($pid)
                    {
                        global $cn;
                        $sql = "select id,name from category where categoryid=".$pid;
                        $table = mysqli_query($cn, $sql);
                        if(mysqli_num_rows($table) > 0)
                        {
                            echo "<ul>";              
                            while($row = mysqli_fetch_assoc($table))
                            {
                            echo  "<li><a href='?c=artical&ctg=".$row['id']."'>".$row['name'] ."</a>";
                            findchild($row['id']); 
                            echo "<li>" ; 
                            }
                            echo "</ul>";
                        }
                         
                    }
            
        if(isset($_SESSION['type']))
        {
            echo '<li><a href="?p=users">Users</a></li>
            <li><a href="?p=category">category</a></li>
            <li><a href="?p=pages">pages</a></li>
            <li><a href="?p=image">Image</a></li>
            <li><a href="?p=file">File</a></li>
            <li><a href="?p=admin">'.$_SESSION['name'].'</a></li>
            <li><a href="?c=logout">Logout</a></li> ';
        }else
        {
           echo '<li><a href="?c=register">Register</a></li>
           <li><a href="?c=login">Login</a></li> '; 
        }
        ?>
               
</ul>
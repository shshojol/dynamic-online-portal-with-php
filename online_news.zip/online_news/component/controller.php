
<?php


if(isset($_GET['p']))
     {
         $p = $_GET['p'];
         if(file_exists("pages/".$p.".php"))
         {
             echo "<span class='title'>".ucwords(str_replace('_',' ',$p))."</span><br>";
             if(isset($_SESSION['type']))
             {
                include("pages/".$p.'.php');
             }else{
                 echo "you have to login to view this content";
                 include("client/login.php");
             }
         }
         else
         {
             include('warning.php');
         }   
     }
    
    elseif(isset($_GET['c']))
     {
        if($_GET['c'] == 'login')
        {
            echo "<span class='title'>login</span><br>";
            
            if(isset($_POST['btnlogin']))
            {
                if(isset($_SESSION['useractive']))
                {
                    echo "plz activate ur account,plz check ur mail";
                    include('client/resend.php');
                }
                elseif(isset($_SESSION['type']))
                {
                   echo "login succesfully";
                }
                else
                {
                   echo 'try again';
                   include('client/login.php');
                }
            }
            else
            {
                include('client/login.php');
            }
        } 
         elseif(file_exists("client/".$_GET['c'].".php"))
         {
             echo "<span class='title'>".ucwords(str_replace('_',' ',$_GET['c']))."</span><br>";
             include("client/".$_GET['c'].'.php');
         }
         else
         {
             include('warning.php');
         }   
     }else
     {
         include('client/home.php');
     }
    
    
?>
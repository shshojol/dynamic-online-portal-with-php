<?PHP
if(!isset($_SESSION['type']) and isset($_COOKIE['type']))
{
    $_SESSION['id'] = $_COOKIE['id'];
    $_SESSION['name'] = $_COOKIE['name'];
    $_SESSION['email'] = $_COOKIE['email'];
    $_SESSION['type'] = $_COOKIE['type'];
}
unset($_SESSION['useractive']);
$email = "";
$eemail = "";
$password = "";
$epassword = "";
if(isset($_POST['btnlogin']))
{
    $email = $_POST['email'];
    $password = $_POST['password'];
    $er = 0;
    if($email == "")
    {
        $er++;
        $eemail = "required";
    }
    if($password == "")
    {
        $er++;
        $epassword = "required";
    }
    if($er == 0)
    {
        $cn = mysqli_connect('localhost', 'root', '', 'dbus_002');
        $sql = "select id, name, email, type from users where email = '".$email."' and password = password('".$password."')";
        $table = mysqli_query($cn, $sql);
        
        if(mysqli_num_rows($table) > 0)
        {
            while($row = mysqli_fetch_assoc($table))
            {
                $sql = "select ip, date from usersactive where userid = ".$row['id'];
                $table2 = mysqli_query($cn, $sql);
                if(mysqli_num_rows($table2) > 0)
                {
                    $_SESSION['id'] = $row['id'];
                    $_SESSION['name'] = $row['name'];
                    $_SESSION['email'] = $row['email'];
                    $_SESSION['type'] = $row['type'];
                    
                    if(isset($_POST['remember']))
                    {
                        setcookie('id', $row['id'], time() + (86400 * 30));
                    }  
                }
                else
                {
                    $_SESSION['useractive'] = 1;
                }
                         
            }
     
        }

    }
}


if(isset($_GET['c']) and $_GET['c'] == 'logout')
{
    unset($_SESSION['id']);
    unset($_SESSION['name']);
    unset($_SESSION['email']);
    unset($_SESSION['type']);
}
?>